const express = require('express')
const app = express()
const port = 8080
const path = require('path');
const cors = require('cors');


// const blog_route = require('api/blog.js');

app.use(express.urlencoded({extended : false}));
app.use('/',require(path.join(__dirname,"routes/blog.js")))
app.use(cors());

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})